extends DrawingTurtlePracticeTester

var expected_rect := [Vector2(0, 0), Vector2(200, 0), Vector2(200, 120), Vector2(0, 120), Vector2(0, 0)]


func _get_turtle() -> DrawingTurtle:
	return _scene_root_viewport.get_child(0)


func _define(checks: Array[Check]) -> void:
	checks.append(Check.new(tr("Rectangle Starts At 120 By 100"), tr(""), test_rectangle_starts_at_120_by_100))
	checks.append(Check.new(tr("Rectangle Size Is 200 By 120"), tr(""), test_rectangle_size_is_200_by_120))


func test_rectangle_starts_at_120_by_100() -> String:
	if shape_count_is(0):
		return tr("We didn't find any drawn rectangles. Did you forget to call draw_rectangle()?")
	
	var turtle := _get_turtle()
	
	var p = turtle.get_polygons()[0]
	if not Vector2(120, 100).is_equal_approx(p.position):
		return tr("The rectangle doesn't start at position (120, 100). Did you not set the position right?")
	return ""


func test_rectangle_size_is_200_by_120() -> String:
	if shape_count_is(0):
		return tr("We didn't find any drawn rectangles. Did you forget to call draw_rectangle()?")
	if not shape_is(0, expected_rect):
		return tr("The drawn shapes don't have the expected length and height. Did you forget to use the length and height parameter?")
	return ""

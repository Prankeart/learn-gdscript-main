extends Node2D

@export var camera_2d: Camera2D

func _ready() -> void:
	set_process(false)
	camera_2d.set_as_top_level(true)


# EXPORT move_and_rotate
func _process(delta):
	rotate(0.05)
	move_local_x(5)
# /EXPORT move_and_rotate


func _run() -> void:
	reset()
	set_process(true)
	await get_tree().create_timer(1.0).timeout
	Events.practice_run_completed.emit()


func reset() -> void:
	rotation = 0.0
	position = Vector2(0, 0)
	set_process(false)

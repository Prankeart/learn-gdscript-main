extends PracticeTester

const ROBOT_CELL := Vector2(5, 3)

var game_board: Node2D
var path := []


func _prepare() -> void:
	game_board = _scene_root_viewport.get_child(0)
	path = game_board.turtle_path


func _prevalidate(invalid_errors: Array[String]) -> bool:
	_prepare()
	
	if not path.all(func(point) -> bool: return point is Vector2):
		invalid_errors.append(tr("Path contains values that are not Vector2"))
		return false
	
	return true


func _define(checks: Array[Check]) -> void:
	checks.append(Check.new(tr("Path Is Contiguous"), tr(""), test_path_is_contiguous))
	checks.append(Check.new(tr("Turtle Reaches The Robot"), tr(""), test_turtle_reaches_the_robot))
	checks.append(Check.new(tr("Path Does Not Hit Obstacles"), tr(""), test_path_does_not_hit_obstacles))


func test_path_is_contiguous() -> String:
	if path.size() == 0:
		return tr("No points found in variable turtle_path. Did you write Vector2 coordinates in the variable's array?")
	var last_point := Vector2(0, 0)
	var first_index := 1 if path.front() == Vector2.ZERO else 0
	for point in path.slice(first_index, path.size()):
		if not is_equal_approx(last_point.distance_to(point), 1):
			return tr("We found at least two points that are not next to one another. Did you forget some coordinates, or did you try to move the turtle diagonally?")
		last_point = point
	return ""


func test_turtle_reaches_the_robot() -> String:
	var last_point = path.back()
	if not last_point or not ROBOT_CELL.is_equal_approx(last_point):
		return (
			tr("The last point should be at the robot's coordinates, %s, but it is %s instead.") % [ROBOT_CELL, last_point]
		)
	return ""


func test_path_does_not_hit_obstacles() -> String:
	var unit_coordinates: Array = game_board.units.values()
	for obstacle in unit_coordinates.slice(2, unit_coordinates.size()):
		if obstacle in path:
			return tr("The turtle hit a rock at coordinates %s. You need to change its path.") % obstacle
	return ""
